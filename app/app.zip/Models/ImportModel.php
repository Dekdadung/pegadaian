<?php

// namespace App\Models;

// use CodeIgniter\Model;

// class ImportModel extends Model
// {

//     public function insert($data)
//     {
//         $insert = $this->db->insert_batch('tbl_data2', $data);
//         if ($insert) {
//             return true;
//         }
//     }
//     public function getData()
//     {
//         $this->db->select('*');
//         return $this->db->get('tbl_data2')->result_array();
//     }
// }
